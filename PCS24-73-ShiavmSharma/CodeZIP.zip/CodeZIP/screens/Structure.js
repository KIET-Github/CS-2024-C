import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { FontAwesome5 } from '@expo/vector-icons';

const Structure = () => {
  const [selectedCrop, setSelectedCrop] = useState('');
  const [cropDetails, setCropDetails] = useState('');

  const handleCropChange = (crop) => {
    setSelectedCrop(crop);
    
    // Update crop details based on the selected crop
    switch (crop) {
      case 'sugarcane':
        setCropDetails(`
        - Planting: February - March\n\n
        - Initial Growth and Development: March - April\n\n
        - Growth and Maintenance: May - July\n\n
        - Maturation and Ripening: August - October\n\n
        - Harvesting: October - November\n\n
        - Post-Harvest: December - January\n\n`);
        break;
      case 'wheat':
        setCropDetails(`
        - Preparation and Sowing: October - November\n\n
        - Early Growth: November - December\n\n
        - Winter Growth: December - February\n\n
        - Tillering and Stem Elongation: February - March\n\n
        - Heading and Flowering: March - April\n\n
        - Grain Filling: April - May\n\n
        - Ripening: May - June\n\n
        - Harvesting: April - June\n\n
        - Post-Harvest: June - July\n\n`);
        break;
      case 'rice':
        setCropDetails(`
        - Land Preparation: March - April\n\n
        - Seedbed Preparation and Sowing: April - May\n\n
        - Transplanting: June - July\n\n
        - Early Growth and Tillering: July - August\n\n
        - Panicle Initiation: August - September\n\n
        - Heading and Flowering: September - October\n\n
        - Grain Formation: October - November\n\n
        - Ripening: November - December\n\n
        - Harvesting: October - December\n\n`);
        break;
      default:
        setCropDetails('');
        break;
    }
  };

  return (
    <View style={styles.container}>
      <FontAwesome5 name="seedling" size={24} color="#FFD700" />
      <Text style={styles.heading}>Structure Chart of Crops</Text>
      <Picker
        selectedValue={selectedCrop}
        onValueChange={handleCropChange}
        style={styles.picker}
        itemStyle={styles.pickerItem}
      >
        <Picker.Item label="Choose your crop" value="" />
        <Picker.Item label="Sugarcane" value="sugarcane" />
        <Picker.Item label="Wheat" value="wheat" />
        <Picker.Item label="Rice" value="rice" />
      </Picker>
      {cropDetails ? (
        <ScrollView style={styles.scrollView}>
          <Text style={styles.description}>{cropDetails}</Text>
        </ScrollView>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#3A3A3A',
    padding: 20,
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 30,
  },
  picker: {
    width: '80%',
    height: 50,
    borderColor: '#00FF00',
    borderWidth: 2,
    marginBottom: 50,
    marginTop: 50,
    color: 'white',
    borderRadius: 8,
    backgroundColor: '#2E8E5E',
  },
  pickerItem: {
    color: 'white',
  },
  scrollView: {
    width: '100%',
  },
  description: {
    fontSize: 16,
    color: 'white',
    textAlign: 'left',
    marginHorizontal: 20,
  },
});

export default Structure;
