import { View, Text ,StyleSheet, TouchableOpacity, Image} from 'react-native';
import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { doc, getDoc} from 'firebase/firestore';
import Animated, { FadeInDown } from 'react-native-reanimated';
import farmer from '../images/farmer.jpeg';

const Profile = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const UserRef=doc(db,"users",auth.currentUser.uid)
        const docSnap=await getDoc(UserRef);
    //    console.log(docSnap.data());
        setData(docSnap.data());
      } catch (error) {
        console.log('Error:', error);
      }
    };
    fetchUserData();
  }, []);
  return (
    <View style={styles.container}>
      <Image style={styles.image}source={farmer}/>
      <Animated.View entering={FadeInDown.delay(400).duration(1000).springify()}>
      <Text style={styles.heading}>Name: {data.Name}</Text>
      <Text style={styles.heading}>Email: {data.Email}</Text>
      <Text style={styles.heading}>Pincode: {data.PincodeNumber}</Text>
      <Text style={styles.heading}>Phone Number: {data.Phoneno}</Text>
      
        <TouchableOpacity style={styles.buttonContainer}>
          <Text style={styles.buttonText}>Edit Profile</Text>
        </TouchableOpacity>
      </Animated.View>      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#3A3A3A',
  },
  image:{
    alignItems: 'center',
    justifyContent: 'center',
    width: 125,
    height: 130,
    borderRadius: 60,
    marginBottom:30,
  },
  heading: {
    padding:20,
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
    backgroundColor:'#006666',
    borderRadius:34,
  },

  buttonContainer: {
    backgroundColor: '#2196F3',
    padding: 15,
    borderRadius: 10,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default Profile;