import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Alert, Image, ImageBackground } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent', // Use 'transparent' background
  },
  button: {
    backgroundColor: '#4CAF50', // Green color
    borderRadius: 10,
    padding: 10,
    width: 200,
    alignItems: 'center',
    marginBottom:20
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff', // White text color
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 10,
    margin: 20,
  },
  internal_container:{
    backgroundColor:'#0A1687',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
  },
  backgroundImage: {
    flex: 1, // Take up the entire screen
  },
});

const App = () => {
  const [image, setImage] = useState(null);

  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission Denied',
          'You need to grant access to your photo library to use this feature.'
        );
      }
    })();
  }, []);

  const choosePhoto = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) { // Use "canceled" instead of "cancelled"
      const selectedAsset = result.assets[0]; // Use assets array
      setImage(selectedAsset.uri);
      Alert.alert('Hello', 'Plant not Detected');
    }
  };

  return (
    <ImageBackground source={{ uri: 'https://media.istockphoto.com/id/483451251/photo/fungal-attack.webp?s=2048x2048&w=is&k=20&c=YzBqjckM9yx_FCqiGCJ0kZcPjBgF7j1mrHfiG7rTKnY=' }} style={styles.backgroundImage}>
      <View style={styles.container}>
        <View style={styles.internal_container}>
        <Text style={{ fontSize: 20, fontWeight: 'bold', margin: 20, color: 'white' }}>
          Disease Detection
        </Text>
        <TouchableOpacity onPress={choosePhoto} style={styles.button}>
          <Text style={styles.buttonText}>Choose Photo</Text>
        </TouchableOpacity>
        </View>
        {image && (
          <Image source={{ uri: image }} style={styles.image} />
        )}
      </View>
    </ImageBackground>
  );
};

export default App;
