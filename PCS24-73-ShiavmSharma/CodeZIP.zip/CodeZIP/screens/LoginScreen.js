import React, { useState, useEffect } from 'react';
import { Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { auth, signInWithEmailAndPassword } from '../firebase';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import background from '../images/background.png';
import light from '../images/light.jpeg';

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      if (user) {
        navigation.replace('AfterLogin');
      }
    });
    return unsubscribe;
  }, []);


  const handleLogin = () => {
    AsyncStorage.setItem('token_email', email);
    AsyncStorage.setItem('token_password', password);
    signInWithEmailAndPassword(auth, email, password)
      .then(userCredential => {
        const user = userCredential.user;
        console.log('Logged in with:', user.email);
      })
      .catch(error => alert(error.message));
  };


  useEffect(() => {
    const signIn = async () => {
      try {
        const te = await AsyncStorage.getItem('token_email');
        const tp = await AsyncStorage.getItem('token_password');
  
        console.log(te, tp);
  
        signInWithEmailAndPassword(auth, te, tp)
          .then(userCredential => {
            const user = userCredential.user;
            console.log('Logged in with:', user.email);
          })
          .catch(error => {
            console.log('Login failed:', error);
          });
      } catch (error) {
        console.log('AsyncStorage error:', error);
      }
    };
  
    signIn();
  }, []);
   

  return (
    <View className="bg-white h-full w-full">
        <StatusBar style="light" />
        <Image className="h-full w-full absolute" source={background} />

        {/* lights */}
        <View className="flex-row justify-around w-full absolute">
            <Animated.Image 
                entering={FadeInUp.delay(200).duration(1000).springify()} 
                source={light}
                className="h-[215] w-[90]" 
            />
            <Animated.Image 
                entering={FadeInUp.delay(400).duration(1000).springify()} 
                source={light}
                className="h-[160] w-[65] opacity-75" 
            />
        </View>
        <View className="h-full w-full flex justify-around pt-40 pb-10">
            
            {/* title */}
            <View className="flex items-center">
                <Animated.Text 
                    entering={FadeInUp.duration(1000).springify()} 
                    className="text-white font-bold tracking-wider text-5xl">
                        Login
                </Animated.Text>
            </View>

            {/* form */}
            <View className="flex items-center mx-5 space-y-4">
                <Animated.View 
                    entering={FadeInDown.duration(1000).springify()} 
                    className="bg-black/5 p-5 rounded-2xl w-full">

                    <TextInput
                        placeholder="Email"
                        placeholderTextColor={'gray'}
                        onChangeText={text => setEmail(text)}
                    />
                </Animated.View>
                <Animated.View 
                    entering={FadeInDown.delay(200).duration(1000).springify()} 
                    className="bg-black/5 p-5 rounded-2xl w-full mb-3">

                    <TextInput

                        placeholder="Password"
                        placeholderTextColor={'gray'}
                        secureTextEntry
                        onChangeText={text => setPassword(text)}
                    />
                </Animated.View>

                <Animated.View 
                    className="w-full" 
                    entering={FadeInDown.delay(400).duration(1000).springify()}>

                    <TouchableOpacity onPress={handleLogin} className="w-full bg-sky-400 p-3 rounded-2xl mb-3">
                        <Text className="text-xl font-bold text-white text-center">Login</Text>
                    </TouchableOpacity>
                </Animated.View>

                <Animated.View 
                    entering={FadeInDown.delay(600).duration(1000).springify()} 
                    className="flex-row justify-center">

                    <Text>Dont have an account? </Text>
                    <TouchableOpacity onPress={()=> navigation.push('Register')}>
                        <Text className="text-sky-600">SignUp</Text>
                    </TouchableOpacity>
                </Animated.View>
            </View>
        </View>
        </View>

  );
};

export default LoginScreen;