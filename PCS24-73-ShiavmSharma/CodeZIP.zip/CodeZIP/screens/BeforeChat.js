import React, { useEffect } from 'react';
import { ImageBackground } from 'react-native';
import { View } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import img from '../images/ChatPortal.jpeg'; // Replace with the path to your image

const BeforeChat = () => {
  const navigation = useNavigation();
  useEffect(() => {
    setTimeout(() => {
      navigation.replace('Chat'); // Use 'Login' instead of 'LoginScreen'
    }, 3000);
  }, []);

  return (
    <ImageBackground source={img} style={{ flex: 1 }}>
      <View style={{ flex: 1 }} />
    </ImageBackground>
  );
};
export default BeforeChat;