import { StyleSheet, Text, View, TextInput, ScrollView, TouchableOpacity, Dimensions} from "react-native";
import React, { useState } from "react";
import { db } from '../firebase';
import { addDoc, collection } from "firebase/firestore";
import { useNavigation } from '@react-navigation/native';


const Colors = { light: "#eeee", grey: "#D8D8D8", gray: "#B2beb5", primary: "#2F3080", secondary:
 "#EEE00E", dark: "#000", white: "#FFFF", deep: "#046DB5", lightBlue: "#00A8DE", text: "#3EADDF",
};


const {height} = Dimensions.get("window");

const Suggestion = () => {
  const [Suggestion, setSuggestion] = useState("");
  const navigation = useNavigation();

  const Send = async () => {
    try {      
      await addDoc(collection(db, "Suggestions"), {
        Message: Suggestion,
      });
      alert("Thank you for your Message 🎉");
      navigation.navigate("Home");
      } catch (err) {
      alert(err.message);
    }
  };
  
  

  return (
    <View style={styles.container}>
      <View style={styles.loginHeader}>
        <Text style={styles.loginHeaderText}>Write to the Developer</Text>
      </View>

      <ScrollView behavior="padding" style={styles.loginContainer}>
        {/* Username */}
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Suggestion</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Write your Message"
            value={Suggestion}
            onChangeText={(text) => setSuggestion(text)}
          />
        </View>
        <TouchableOpacity style={styles.loginButton} onPress={Send}>
            <Text style={styles.loginButtonText}>Send</Text>
        </TouchableOpacity>
        </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 15,
    marginTop: height * 0.05,
  },
  arrowContainer: {
    width: 40,
    height: 40,
    borderTopLeftRadius: 8,
    borderBottomRightRadius: 8,
    backgroundColor: Colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  loginHeader: {
    marginTop: 7,
  },
  loginHeaderText: {
    fontSize: 36,
    fontWeight: "bold",
  },
  loginContainer: {
    marginTop: 20,
  },
  emailContainer: {
    marginTop: 16,
  },
  emailText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  emailInput: {
    marginTop: 10,
    width: "100%",
    height: 50,
    backgroundColor: Colors.light,
    borderWidth: 1,
    borderColor: Colors.light,
    borderRadius: 8,
    paddingLeft: 10,
  },
  passwordContainer: {
    marginTop: 20,
  },
  passwordText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  passwordInput: {
    marginTop: 10,
    width: "100%",
    height: 50,
    backgroundColor: Colors.light,
    borderRadius: 8,
    paddingLeft: 10,
    borderWidth: 1,
    borderColor: Colors.light,
  },
  forgotContainer: {
    marginTop: 20,
    alignItems: "flex-end",
  },
  forgotText: {
    fontSize: 16,
    fontWeight: "bold",
    color: Colors.primary,
  },
  loginButton: {
    marginTop: 20,
    width: "100%",
    height: 50,
    backgroundColor: Colors.primary,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: "bold",
    color: Colors.white,
  },
  signupGroup: {
    flexDirection: "row",
    marginTop: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  signup: {
    color: Colors.primary,
    fontSize: 16,
    fontWeight: "bold",
    marginRight: 5,
  },
  new: {
    fontSize: 16,
    fontWeight: "500",
    marginRight: 5,
  },
});

export default Suggestion;