import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ImageBackground, Dimensions, StatusBar, TextInput, ActivityIndicator } from 'react-native';
import { EvilIcons } from '@expo/vector-icons';
import haze from '../images/haze.jpg';
import snow from '../images/snow.jpg';
import rainy from '../images/rainy.jpg';
import sunny from '../images/sunny.jpg';

const API_KEY = "46a9246bebba16d42b36aac3fc3ba8af";

export default function WeatherApp() {
    const [weatherData, setWeatherData] = useState(null);
    const [loaded, setLoaded] = useState(true);
    const [cityName, setCityName] = useState('');

    async function fetchWeatherData(city) {
        setLoaded(false);
        const API = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`;
        try {
            const response = await fetch(API);
            if (response.status == 200) {
                const data = await response.json();
                setWeatherData(data);
            } else {
                setWeatherData(null);
            }
            setLoaded(true);
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        fetchWeatherData('Ghaziabad');
    }, []);

    function getBackgroundImg(weather) {
        if (weather === 'Snow') return snow;
        if (weather === 'Clear') return sunny;
        if (weather === 'Rain') return rainy;
        if (weather === 'Haze') return haze;
        return haze;
    }

    let textColor = weatherData !== null && weatherData.weather[0].main !== 'Clear' ? 'white' : 'black';

    if (!loaded) {
        return (
            <View style={styles.container}>
                <ActivityIndicator color='gray' size={36} />
            </View>
        );
    } else if (weatherData === null) {
        return (
            <View style={styles.container}>
                <View style={styles.searchBar}>
                    <TextInput
                        placeholder='Enter City name'
                        value={cityName}
                        onChangeText={(text) => setCityName(text)}
                        style={{ flex: 1 }}
                    />
                    <EvilIcons name="search" size={40} color="blue" onPress={() => fetchWeatherData(cityName)} />
                </View>
                <Text style={styles.primaryText}>City Not Found! Try a Different City</Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <StatusBar backgroundColor='darkgray' />
            <ImageBackground
                source={getBackgroundImg(weatherData.weather[0].main)}
                style={styles.backgroundImg}
                resizeMode='cover'
            >
                <View style={styles.searchBar}>
                    <TextInput
                        placeholder='Enter City name'
                        value={cityName}
                        onChangeText={(text) => setCityName(text)}
                        style={{ flex: 1 }}
                    />
                    <EvilIcons name="search" size={40} color="blue" onPress={() => fetchWeatherData(cityName)} />
                </View>
                <View style={{ alignItems: 'center' }}>
                    <Text style={{ ...styles.headerText, color: textColor, fontWeight: 'bold', fontSize: 46 }}>{weatherData.name}</Text>
                    <Text style={{ ...styles.headerText, color: textColor, fontWeight: 'bold' }}>{weatherData.weather[0].main}</Text>
                    <Text style={{ ...styles.headerText, color: textColor }}>{weatherData.main.temp} °C</Text>
                </View>

                <View style={styles.extraInfo}>
                    <View style={styles.info}>
                        <Text style={{ fontSize: 22, color: 'white' }}>Humidity</Text>
                        <Text style={{ fontSize: 22, color: 'white' }}>{weatherData.main.humidity} %</Text>
                    </View>

                    <View style={styles.info}>
                        <Text style={{ fontSize: 22, color: 'white' }}>Wind Speed</Text>
                        <Text style={{ fontSize: 22, color: 'white' }}>{weatherData.wind.speed} m/s</Text>
                    </View>
                </View>
            </ImageBackground>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    backgroundImg: {
        flex: 1,
        width: Dimensions.get('screen').width
    },
    headerText: {
        fontSize: 36,
        marginTop: 10,
    },
    extraInfo: {
        flexDirection: 'row',
        marginTop: 20,
        justifyContent: 'space-between',
        padding: 10
    },
    info: {
        width: Dimensions.get('screen').width / 2.5,
        backgroundColor: 'rgba(0,0,0, 0.5)',
        padding: 10,
        borderRadius: 15,
        justifyContent: 'center'
    },
    searchBar: {
        marginTop: 35,
        marginBottom:50,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: Dimensions.get('screen').width - 20,
        borderWidth: 1.5,
        paddingVertical: 10,
        borderRadius: 25,
        marginHorizontal: 10,
        paddingHorizontal: 15, // Updated padding here
        backgroundColor: 'lightgray',
        borderColor: 'lightgray',
    },
    primaryText: {
        margin: 20,
        fontSize: 28,
    },
});
