import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { FontAwesome5 } from '@expo/vector-icons';

const Resource = () => {
  const [selectedCrop, setSelectedCrop] = useState('');

  const handleCropChange = (crop) => {
    setSelectedCrop(crop);
  };

  return (
    <View style={styles.container}>
      <FontAwesome5 name="seedling" size={24} color="#FFD700" />
      <Text style={styles.heading}>Resource Sharing</Text>
      <Picker
        selectedValue={selectedCrop}
        onValueChange={handleCropChange}
        style={styles.picker}
        itemStyle={styles.pickerItem}
      >
        <Picker.Item label="Choose what you need" value="" />
        <Picker.Item label="Tractor" value="Tractor" />
        <Picker.Item label="Equipments" value="Equipments" />
        <Picker.Item label="Generator" value="Generator" />
      </Picker>
      {selectedCrop ? (
        <Text style={styles.description}>{`${selectedCrop} is unavailable`}</Text>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#3A3A3A',
    padding: 20,
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 30,
  },
  picker: {
    width: '80%',
    height: 50,
    borderColor: '#00FF00',
    borderWidth: 2,
    marginBottom: 50,
    marginTop: 50,
    color: 'white',
    borderRadius: 8,
    backgroundColor: '#2E8E5E',
  },
  pickerItem: {
    color: 'white',
  },
  description: {
    fontSize: 18,
    color: 'white',
    textAlign: 'center',
  },
});

export default Resource;
