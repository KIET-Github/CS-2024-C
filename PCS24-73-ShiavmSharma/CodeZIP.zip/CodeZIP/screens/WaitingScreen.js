import React, { useEffect } from 'react';
import { ImageBackground } from 'react-native';
import { View } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import stockImage from '../images/openpage.jpeg'; // Replace with the path to your image

const WaitingScreen = () => {
  const navigation = useNavigation();

  useEffect(() => {
    setTimeout(() => {
      navigation.replace('Welcome'); // Use 'Login' instead of 'LoginScreen'
    }, 3000);
  }, []);

  return (
    <ImageBackground source={stockImage} style={{ flex: 1 }}>
      <View style={{ flex: 1 }} />
    </ImageBackground>
  );
};

export default WaitingScreen;
