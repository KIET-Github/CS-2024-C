import { StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView, Dimensions} from "react-native";
import React, { useState } from "react";
import { useNavigation } from '@react-navigation/native';
import { auth, db } from '../firebase';
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

const Colors = { light: "#eeee",
  grey: "#D8D8D8",
  gray: "#B2beb5",
  primary: "#2F3080",
  secondary: "#EEE00E",
  dark: "#000",
  white: "#FFFF",
  deep: "#046DB5",
  lightBlue: "#00A8DE",
  text: "#3EADDF",
};


const {height} = Dimensions.get("window");

const Register = () => {
  const navigation = useNavigation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [Pincode, setPincode] = useState("");
  const [Phoneno, setPhoneno] = useState("");
  const [Profession, setProfession] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email.trim(),
        password
      );

      const user = userCredential.user;
      setLoading(false);

      await setDoc(doc(db, "users", user.uid), {
        Name: username,
        Email: email,
        PincodeNumber: Pincode,
        CreatedAt: new Date().toUTCString(),
        Phoneno:Phoneno,
        Profession: Profession,
      });

      alert("Account created successfully 🎉");

      // Navigate to the Home screen
      navigation.navigate("Home");
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.loginHeader}>
        <Text style={styles.loginHeaderText}>Sign up :)</Text>
      </View>

      <ScrollView behavior="padding" style={styles.loginContainer}>
        {/* Username */}
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Username</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Enter your name"
            value={username}
            onChangeText={(text) => setUsername(text)}
          />
        </View>
        {/* Email */}
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Email</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Enter your email"
            value={email}
            onChangeText={(text) => setEmail(text)}
          />
        </View>
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Profession</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Enter your Profession"
            value={Profession}
            onChangeText={(text) => setProfession(text)}
          />
        </View>
        {/* Phone */}
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Mobile Number</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Enter your Mobile Number"
            value={Phoneno}
            onChangeText={(text) => setPhoneno(text)}
          />
        </View>
        {/* Pincode Number */}
        <View style={styles.emailContainer}>
          <Text style={styles.emailText}>Pincode Number</Text>
          <TextInput
            style={styles.emailInput}
            placeholder="Enter your Pincode number"
            value={Pincode}
            keyboardType="numeric"
            onChangeText={(text) => setPincode(text)}
          />
        </View>
        {/* Password */}
        <View style={styles.passwordContainer}>
          <Text style={styles.passwordText}>Password</Text>
          <TextInput
            style={styles.passwordInput}
            placeholder="Enter your password"
            value={password}
            secureTextEntry={true}
            onChangeText={(text) => setPassword(text)}
          />
        </View>
        {/* Forgot Password */}

        {/* Login Button */}
        <TouchableOpacity style={styles.loginButton} onPress={handleSignup}>
            <Text style={styles.loginButtonText}>
              {loading ? "Creating account..." : "Create Account"}
            </Text>
        </TouchableOpacity>

        <View style={styles.signupGroup}>
          <Text style={styles.new}>Already have an account?</Text>
          <TouchableOpacity onPress={() => navigation.navigate("Welcome")}>
            <Text style={styles.signup}>Login</Text>
          </TouchableOpacity>
        </View>
        </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 15,
    marginTop: height * 0.05,
  },
  arrowContainer: {
    width: 40,
    height: 40,
    borderTopLeftRadius: 8,
    borderBottomRightRadius: 8,
    backgroundColor: Colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  loginHeader: {
    marginTop: 7,
  },
  loginHeaderText: {
    fontSize: 36,
    fontWeight: "bold",
  },
  loginContainer: {
    marginTop: 20,
  },
  emailContainer: {
    marginTop: 16,
  },
  emailText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  emailInput: {
    marginTop: 10,
    width: "100%",
    height: 50,
    backgroundColor: Colors.light,
    borderWidth: 1,
    borderColor: Colors.light,
    borderRadius: 8,
    paddingLeft: 10,
  },
  passwordContainer: {
    marginTop: 20,
  },
  passwordText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  passwordInput: {
    marginTop: 10,
    width: "100%",
    height: 50,
    backgroundColor: Colors.light,
    borderRadius: 8,
    paddingLeft: 10,
    borderWidth: 1,
    borderColor: Colors.light,
  },
  forgotContainer: {
    marginTop: 20,
    alignItems: "flex-end",
  },
  forgotText: {
    fontSize: 16,
    fontWeight: "bold",
    color: Colors.primary,
  },
  loginButton: {
    marginTop: 20,
    width: "100%",
    height: 50,
    backgroundColor: Colors.primary,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: "bold",
    color: Colors.white,
  },
  signupGroup: {
    flexDirection: "row",
    marginTop: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  signup: {
    color: Colors.primary,
    fontSize: 16,
    fontWeight: "bold",
    marginRight: 5,
  },
  new: {
    fontSize: 16,
    fontWeight: "500",
    marginRight: 5,
  },
});

export default Register;