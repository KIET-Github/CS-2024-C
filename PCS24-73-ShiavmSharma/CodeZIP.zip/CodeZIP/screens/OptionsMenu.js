import React, { useState } from 'react';
import { Text, TouchableOpacity, View, Modal, StyleSheet, Alert, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth } from '../firebase';
import { useTranslation } from 'react-i18next'; // Import useTranslation hook
import i18n from '../services/i18next'; // Import the i18n instance
//import HomeScreen from './screens/Homescreen';

const OptionsMenu = () => {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const { t } = useTranslation(); // Use the useTranslation hook to access translations

  const openMenu = () => {
    setModalVisible(true);
  };

  const closeMenu = () => {
    setModalVisible(false);
  };

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    closeMenu();
  };

  const showAlert = () => {
    Alert.alert(
      t('selectLanguage'), // Use t function to translate keys
      t('chooseLanguage'), // Use t function to translate keys
      [
        {
          text: 'हिंदी',
          onPress: () => {
            changeLanguage('hn');
          },
          
        },
        {
          text: 'English',
          onPress: () => {
            changeLanguage('en');
          },
        },
      ],
      { cancelable: true }
    );
  };

  const handleSignOut = async () => {
    Alert.alert(
      t('confirmSignOut'), // Use t function to translate keys
      t('wantToSignOut'), // Use t function to translate keys
      [
        {
          text: t('no'), // Use t function to translate keys
          style: 'cancel',
        },
        {
          text: t('yes'), // Use t function to translate keys
          onPress: async () => {
            try {
              await auth.signOut();
              await AsyncStorage.removeItem('token_email');
              await AsyncStorage.removeItem('token_password');
              navigation.replace('Welcome');
            } catch (error) {
              console.error('Error signing out:', error);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  return (
    <View >
      <TouchableOpacity onPress={openMenu}>
        <Image source={{uri:'https://www.iconpacks.net/icons/2/free-icon-user-3296.png'}} style={styles.imageIcon} />
      </TouchableOpacity>
      <Modal
        transparent={true}
        animationType="slide"
        visible={modalVisible}
        onRequestClose={closeMenu}
        presentationStyle="overFullScreen"
      >
        <View style={styles.modalContainer}>
          <View style={styles.menu}>
            <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
              <View style={styles.buttonTextContainer}>
                <Text style={styles.buttonText}>{t('profile')}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Home')}>
              <View style={styles.buttonTextContainer}>
                <Text style={styles.buttonText}>{t('settings')}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={showAlert}>
              <View style={styles.buttonTextContainer}>
                <Text style={styles.buttonText}>{t('language')}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleSignOut}>
              <View style={styles.buttonTextContainer}>
                <Text style={styles.buttonText}>{t('signout')}</Text>
              </View>
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.overlay} onPress={closeMenu} />
        </View>
      </Modal>
    </View>
  );
};


const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    flexDirection: 'row-reverse', // Align content in a row with the main axis reversed
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  menu: {
    backgroundColor: '#87391D',
    width: 170, // Adjust the width as needed
    padding: 16,
    borderLeftWidth: 2,
    borderLeftColor: '#ccc',
  },
  imageIcon: {
    width: 30, 
    height: 30, 
  },
  buttonTextContainer: {
    backgroundColor: '#FFD700',
    padding: 10,
    borderRadius: 5,
    marginBottom:5
  },
  buttonText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#000',
  },
});

export default OptionsMenu;
