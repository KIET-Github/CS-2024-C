const Colors = {
    primary: '#f57c00',
    gray: '#C5C5C7',
    mediumGray: '#F6F7FB',
    lightGray: '#FAFAFA',
    light: "#eeee",
    grey: "#D8D8D8",
    secondary: "#EEE00E",
    dark: "#000",
    white: "#FFFF",
    deep: "#046DB5",
    lightBlue: "#00A8DE",
    text: "#3EADDF",
  };
  
  export default Colors;