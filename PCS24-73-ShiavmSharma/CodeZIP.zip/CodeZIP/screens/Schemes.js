import React from 'react';
import WebView from 'react-native-webview';

const News=()=>{
    return(
        <WebView
        source={{uri:'https://www.nabard.org/content1.aspx?id=23&catid=23&mid=530'}}
        />
    )
}
export default News;