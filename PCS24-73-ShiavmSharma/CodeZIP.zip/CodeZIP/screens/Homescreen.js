import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View, ScrollView, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next'; // Import useTranslation hook

import img1 from '../images/img1.jpeg';
import img3 from '../images/img3.jpeg';
import img4 from '../images/img4.jpeg';
import img5 from '../images/img5.jpeg';
import img6 from '../images/img6.jpeg';
import Emi from '../images/Emi.jpeg';
import community from '../images/community.jpeg';
import scheme from '../images/scheme.jpeg';
import support from '../images/support.jpeg';

const HomeScreen = () => {
  const navigation = useNavigation();
  const { t } = useTranslation(); // Use the useTranslation hook to access translations

  const navigateToFeature = (feature) => {
    switch (feature) {
      case t('weather'):
        navigation.navigate('WeatherApp');
        break;
      case t('community'):
        navigation.navigate('BeforeChat');
        break;
      case t('news'):
        navigation.navigate('News');
        break;
      case t('disease'):
        navigation.navigate('Disease');
        break;
      case t('roadMap'):
        navigation.navigate('Structure');
        break;
      case t('emi'):
        navigation.navigate('Emi');
        break;
      case t('schemes'):
        navigation.navigate('Schemes');
        break;
      case t('resource'):
        navigation.navigate('Resource');
        break;
      case t('suggestion'):
        navigation.navigate('Suggestion');
        break;
      default:
        navigation.navigate('WeatherApp');
    }
  };

  const features = [
    { title: t('weather'), image: img5 },
    { title: t('community'), image: community },
    { title: t('news'), image: img6 },
    { title: t('disease'), image: img4 },
    { title: t('roadMap'), image: img1 },
    { title: t('emi'), image: Emi },
    { title: t('schemes'), image: scheme },
    { title: t('resource'), image: img3 },
    { title: t('suggestion'), image: support }
  ];

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {features.map((feature) => (
          <FeatureButton key={feature.title} title={t(feature.title)} image={feature.image} onPress={() => navigateToFeature(feature.title)} />
        ))}
      </ScrollView>
    </View>
  );
};

const FeatureButton = ({ title, image, onPress }) => (
  <TouchableOpacity style={styles.featureCard} onPress={onPress}>
    <Image source={image} style={styles.featureImageContainer} />
    <View style={styles.buttonTextContainer}>
      <Text style={styles.buttonText}>{title}</Text>
    </View>
  </TouchableOpacity>
);


FeatureButton.propTypes = {
  title: PropTypes.string.isRequired,
  image: PropTypes.any.isRequired,
  onPress: PropTypes.func.isRequired,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  scrollContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    padding: 10,
  },
  featureCard: {
    width: '48%',
    aspectRatio: 0.9,
    borderRadius: 20,
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden', // Hide the overflow of the background color
  },
  featureImageContainer: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
    overflow: 'hidden', // Hide the overflow of the image
  },
  buttonTextContainer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: 'rgba(255, 215, 215, 0.8)', // Semi-transparent background color
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 11,
    fontWeight: 'bold',
    textAlign:'center',
    color: '#000',
  },
});

export default HomeScreen;
