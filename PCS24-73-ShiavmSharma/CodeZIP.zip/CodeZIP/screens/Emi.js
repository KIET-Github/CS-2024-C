import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView } from 'react-native';

const EMICalculator = () => {
  const [principalAmount, setPrincipalAmount] = useState('');
  const [time, setTime] = useState('');
  const [roi, setRoi] = useState('');
  const [emi, setEMI] = useState(0);
  const [error, setError] = useState('');

  const calculateEMI = () => {
    if (principalAmount && time && roi) {
      const principal = parseFloat(principalAmount);
      const months = parseInt(time);
      const interest = parseFloat(roi);

      if (isNaN(principal) || isNaN(months) || isNaN(interest)) {
        setError('Please enter valid numeric values');
        setEMI(0);
      } else {
        const interestRate = interest / 1200;
        const emiValue =
          (principal * interestRate) /
          (1 - Math.pow(1 + interestRate, -months));

        setEMI(emiValue.toFixed(2));
        setError('');
      }
    } else {
      setError('Please fill all fields to calculate EMI');
      setEMI(0);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>EMI Calculator</Text>

      <View style={styles.content}>
        <Text style={styles.label}>Enter Principal Amount:</Text>
        <TextInput
          style={styles.input}
          value={principalAmount}
          onChangeText={(text) => setPrincipalAmount(text)}
          keyboardType="numeric"
          placeholder="Principal Amount"
        />

        <Text style={styles.label}>Enter Time (in months):</Text>
        <TextInput
          style={styles.input}
          value={time}
          onChangeText={(text) => setTime(text)}
          keyboardType="numeric"
          placeholder="Time"
        />

        <Text style={styles.label}>Enter Rate of Interest (in %):</Text>
        <TextInput
          style={styles.input}
          value={roi}
          onChangeText={(text) => setRoi(text)}
          keyboardType="numeric"
          placeholder="Rate of Interest"
        />

        <Button title="Calculate EMI" onPress={calculateEMI} />

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Text style={styles.result}>
          {emi > 0 ? `EMI: ${emi} Per Month` : ''}
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    backgroundColor: '#3A3A3A',
    padding: 20,
    marginTop: 20, // Adjust the margin-top for content start position
  },
  content: {
    width: '100%',
  },
  heading: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 20,
    marginTop: 80,
  },
  label: {
    fontSize: 18,
    marginTop: 20,
    color: 'white',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    width: '100%',
    marginTop: 10,
    marginBottom: 10,
    paddingHorizontal: 10,
    backgroundColor: 'white',
  },
  result: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: 'bold',
    color: 'white',
    borderRadius:30,
  },
  error: {
    fontSize: 16,
    marginTop: 10,
    color: 'red',
  },
});

export default EMICalculator;
