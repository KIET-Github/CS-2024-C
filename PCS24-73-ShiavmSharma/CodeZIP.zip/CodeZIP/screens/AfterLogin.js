import React, { useEffect } from 'react';
import { ImageBackground } from 'react-native';
import { View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import stockImage from '../images/afterlogin.jpeg'; 

const AfterLogin = () => {
  const navigation = useNavigation();

  useEffect(() => {
    setTimeout(() => {
      navigation.replace('Home'); 
    }, 1500);
  }, []);

  return (
    <ImageBackground source={stockImage} style={{ flex: 1 }}>
      <View style={{ flex: 1 }} />
    </ImageBackground>
  );
};

export default AfterLogin;